#ifndef __SSD_DEVICE_H
#define __SSD_DEVICE_H

void timRD_write(char* mem, unsigned int addr, int pages);
void timRD_read(char* mem, unsigned addr, int pages);

int ssd_init(void);
void ssd_cleanup(void);

#endif /* __SSD_DEVICE_H */
